package com.niit.BackendDaoImpl;
import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.BackendDao.*;
import com.niit.BackendModel.Category;
@Repository("backendCategoryDao")
@Transactional

public class BackendCategoryDaoImpl implements BackendCategoryDao {
@Autowired
SessionFactory sessionFactory;
	
	@Override
	public void addCategory(Category category) {
		sessionFactory.getCurrentSession().saveOrUpdate(category);
	}

	@Override
	public List<Category> getCategory() {
		return  sessionFactory.getCurrentSession().createQuery("from Category").list();
	}

	@Override
	public List<Category> getAllCategory() {
		return sessionFactory.getCurrentSession().createQuery("from Category").list();
	}

	@Override
	public void deleteCategory(Integer Cid) {
		Category category = (Category) sessionFactory.getCurrentSession().load(Category.class, Cid);
		if (category !=null ) {
			this.sessionFactory.getCurrentSession().delete(category);
		
	}
	}
	@Override
	public Category updateCategory(Category category) {
		sessionFactory.getCurrentSession().update(category);
		return category;
	}
	

}
