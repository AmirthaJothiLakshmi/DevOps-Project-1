package com.niit.BackendDaoImpl;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.BackendDao.BackendProductDao;
import com.niit.BackendModel.Product;



@Repository("backendProductDao")
@Transactional
public class BackendProductDaoImpl implements BackendProductDao {

@Autowired
SessionFactory sessionFactory;

	public void addProduct(Product product) {
		sessionFactory.getCurrentSession().saveOrUpdate(product);
		
	}
	public List<Product> getProduct() {
		return  sessionFactory.getCurrentSession().createQuery("from Product").list();
	}
	public List<Product> getAllProduct() {
		return sessionFactory.getCurrentSession().createQuery("from Product").list();
		
	}
	public Product updateProduct(Product product) {
		sessionFactory.getCurrentSession().update(product);
		return product;
	}
	public void deleteProduct(Integer Pid) {
		Product product = (Product) sessionFactory.getCurrentSession().load(Product.class, Pid);
		if (product!=null ) {
			this.sessionFactory.getCurrentSession().delete(product);
		}
		
	}
	
}