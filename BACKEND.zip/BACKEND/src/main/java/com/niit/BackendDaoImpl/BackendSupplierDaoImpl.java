package com.niit.BackendDaoImpl;

import java.util.List;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.BackendDao.BackendSupplierDao;
import com.niit.BackendModel.Product;
import com.niit.BackendModel.Supplier;

@Repository("backendSupplierDao")
@Transactional
public class BackendSupplierDaoImpl implements BackendSupplierDao {

	@Autowired
	SessionFactory sessionFactory;
	
	@Override
	public void addSupplier(Supplier supplier) {
		sessionFactory.getCurrentSession().saveOrUpdate(supplier);
	}

	@Override
	public List<Supplier> getSupplier() {
		return  sessionFactory.getCurrentSession().createQuery("from Supplier").list();
	}

	@Override
	public List<Supplier> getAllSupplier() {
		return sessionFactory.getCurrentSession().createQuery("from Supplier").list();
	}

	@Override
	public Supplier  updateSupplier (Supplier supplier) {
		sessionFactory.getCurrentSession().update(supplier);
		return supplier;
	}

	@Override
	public void deleteSupplier(Integer Sid) {
		Supplier supplier = (Supplier) sessionFactory.getCurrentSession().load(Supplier.class, Sid);
		if (supplier!=null ) {
			this.sessionFactory.getCurrentSession().delete(supplier);
	}

}
}