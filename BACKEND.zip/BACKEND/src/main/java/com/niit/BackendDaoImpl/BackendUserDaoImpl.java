package com.niit.BackendDaoImpl;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.BackendDao.BackendUserDao;
import com.niit.BackendModel.User;
@Repository("backendUserDao")
@Transactional
public class BackendUserDaoImpl implements BackendUserDao {

	@Autowired
SessionFactory sessionFactory;

	public void addUser(User user) {
		sessionFactory.getCurrentSession().saveOrUpdate(user);
		
	}
	public List<User> getUser() {
		return  sessionFactory.getCurrentSession().createQuery("from User").list();
	}
	public List<User> getAllUser() {
		return sessionFactory.getCurrentSession().createQuery("from User").list();
		
	}
	public User updateUser(User user) {
		sessionFactory.getCurrentSession().update(user);
		return user;
	}
	public void deleteUser(Integer Uid) {
		User user = (User) sessionFactory.getCurrentSession().load(User.class, Uid);
		if (user != null) {
			this.sessionFactory.getCurrentSession().delete(user);
		}
		
	}
	
}
