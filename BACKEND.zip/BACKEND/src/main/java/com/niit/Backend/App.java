package com.niit.Backend;

import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

import com.niit.BackendConfig.DBConfig;
import com.niit.BackendDao.BackendCategoryDao;
import com.niit.BackendDao.BackendProductDao;
import com.niit.BackendDao.BackendSupplierDao;
import com.niit.BackendDao.BackendUserDao;
import com.niit.BackendModel.Category;
import com.niit.BackendModel.Product;
import com.niit.BackendModel.Supplier;
import com.niit.BackendModel.User;


public class App 
{ 
	private static AbstractApplicationContext context;
    public static void main( String[] args )
    {
    	context = new AnnotationConfigApplicationContext(DBConfig.class);
   	 	
   	 	User user=new User();
   	 	user.setUid(100);
   	 	user.setUnmae("Amirtha");
   	 	user.setPwd("1234");
   	 	user.setMobno("9944619978");
   	 	user.setEmailid("aaa@gmail.com");
   	 	BackendUserDao userDao = (BackendUserDao) context.getBean("backendUserDao");
   	 	userDao.addUser(user);
   	 	/*user.setPwd("12345");
   	 	userDAO.updateUser(user);*/
   	 	user.getUid();
   	 	userDao.deleteUser(100);
   	 	List<User> userList=userDao.getUser();
   	 	for(User userobj:userList)
   	 	{
   	 		System.out.println(userobj.getUid());
   	 		System.out.println(userobj.getUnmae());
   	 	}
   	 	
   	 	//Product
   	 	
   	  	Product product=new Product();
   		product.setPid(200);
   		product.setPname("Mobile");
   		product.setPrice(10000.35);
   		product.setQuantity(3);
   		product.setDescription("Screen size is 6 inch");
   		BackendProductDao productDao = (BackendProductDao) context.getBean("backendProductDao");
   	   	productDao.addProduct(product);
   	   	//productDao.updateProduct(product);
   	   	product.getPid();
   	   	productDao.deleteProduct(200);
	 	List<Product> productList=productDao.getProduct();
	 	for(Product productobj:productList)
	 	{
	 		System.out.println(productobj.getPid());
	 		System.out.println(productobj.getPname());
	 	}
   	 	
	 	
	 	//Supplier
	 	
	 	Supplier supplier=new Supplier();
	 	supplier.setSid(300);
	 	supplier.setSname("Prabha");
	 	supplier.setDescription("Supplying product from 1990");
   		BackendSupplierDao supplierDao = (BackendSupplierDao) context.getBean("backendSupplierDao");
   		supplierDao.addSupplier(supplier);
   	   	//productDao.updateProduct(product);
   	   	supplier.getSid();
   	   	supplierDao.deleteSupplier(300);
	 	List<Supplier> supplierList=supplierDao.getSupplier();
	 	for(Supplier supplierobj:supplierList)
	 	{
	 		System.out.println(supplierobj.getSid());
	 		System.out.println(supplierobj.getSname());
	 	}
   	 	
	 	//Category
	 		 	
	 	Category category=new Category();
	 	category.setCid(400);
	 	category.setCname("Electronics");
	 	category.setDescription("Fast moving category of products");
   		BackendCategoryDao categoryDao = (BackendCategoryDao) context.getBean("backendCategoryDao");
   		categoryDao.addCategory(category);
   	   	//productDao.updateProduct(product);
   		category.getCid();
   		categoryDao.deleteCategory(400);
	 	List<Category>categoryList=categoryDao.getCategory();
	 	for(Category categoryobj:categoryList)
	 	{
	 		System.out.println(categoryobj.getCid());
	 		System.out.println(categoryobj.getCname());
	 	}
	 	
   	 	
   	 	
    }
}
