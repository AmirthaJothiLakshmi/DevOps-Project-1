package com.niit.BackendDao;

import java.util.List;

import com.niit.BackendModel.Product;
import com.niit.BackendModel.User;

public interface BackendProductDao {
	public void addProduct(Product product);
	public List<Product> getProduct();
	public List<Product> getAllProduct();

	public void deleteProduct(Integer Pid);

	public Product updateProduct(Product product);
}
