package com.niit.BackendDao;

import java.util.List;

import com.niit.BackendModel.Category;

public interface BackendCategoryDao{
	public void addCategory(Category category);
	public List<Category> getCategory();
	public List<Category> getAllCategory();

	public void deleteCategory(Integer Uid);

	public Category updateCategory(Category category);
	
}
