package com.niit.BackendDao;

import java.util.List;

import com.niit.BackendModel.Supplier;

public interface BackendSupplierDao {

	public void addSupplier(Supplier supplier);
	public List<Supplier> getSupplier();
	public List<Supplier> getAllSupplier();

	public void deleteSupplier(Integer Sid);

	public Supplier updateSupplier(Supplier supplier);
}