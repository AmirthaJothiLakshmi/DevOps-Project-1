package com.niit.BackendDao;

import java.util.List;

import com.niit.BackendModel.User;



public interface BackendUserDao {
	public void addUser(User user);
	public List<User> getUser();
	public List<User> getAllUser();

	public void deleteUser(Integer Uid);

	public User updateUser(User user);


}
