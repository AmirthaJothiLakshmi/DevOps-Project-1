package com.niit.BackendModel;

import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class Supplier {
	@Id
	int sid;
	String sname;
	String description;
	
	
	public int getSid() {
		return sid;
	}
	public void setSid(int sid) {
		this.sid = sid;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
}


