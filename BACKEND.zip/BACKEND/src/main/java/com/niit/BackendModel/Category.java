package com.niit.BackendModel;

import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class Category {
	@Id
	int cid;
	String cname;
	String description;
	
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}


}
